﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZXing;

namespace basicQrCodeMaker
{
    public partial class Form1 : Form
    {
        public String url = "";
        public Color back = Color.White;
        public Color front = Color.Black;
        public int width = 500;
        public int height = 500;
        public int margin = 3;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtUrl_TextChanged(object sender, EventArgs e)
        {
            url = txtUrl.Text;
            UpdateQr();

        }

        private void backPanel_Click(object sender, EventArgs e)
        {
            ColorDialog colorPicker = new ColorDialog();
            if (colorPicker.ShowDialog() == DialogResult.OK)
            {
                back = colorPicker.Color;
                backPanel.BackColor = colorPicker.Color;
                UpdateQr();
            }
        }

        private void frontPanel_Click(object sender, EventArgs e)
        {
            ColorDialog colorPicker = new ColorDialog();
            if (colorPicker.ShowDialog() == DialogResult.OK)
            {
                front = colorPicker.Color;
                frontPanel.BackColor = colorPicker.Color;
                UpdateQr();
            }
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private bool isDragging = false;
        private Point dragStartPoint;
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            isDragging = true;
            dragStartPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point dragEnd = PointToScreen(new Point(e.X, e.Y));
                Location = new Point(dragEnd.X - dragStartPoint.X, dragEnd.Y - dragStartPoint.Y);
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            isDragging = false;
        }


        private void btnSavea_Click(object sender, EventArgs e)
        {
            SaveQr();
        }


        void UpdateQr() 
        {
            string data = url;

            // QR kodunu oluştur
            BarcodeWriter barcodeWriter = new BarcodeWriter();
            barcodeWriter.Format = BarcodeFormat.QR_CODE;
            barcodeWriter.Options = new ZXing.Common.EncodingOptions
            {
                Width = width,  // Genişlik
                Height = height, // Yükseklik
                Margin = margin    // Kenar boşluğu
            };

            // Renk ayarları
            barcodeWriter.Renderer = new ZXing.Rendering.BitmapRenderer { Foreground = front, Background = back };

            // QR kodunu resim olarak oluştur
            if(url != "") 
            { 
                Bitmap qrCodeBitmap = barcodeWriter.Write(data);
                qrPicture.Image = qrCodeBitmap;
            }
            // Resmi kaydet veya görüntüle
            //qrCodeBitmap.Save("example_qr_code.png");
            //System.Diagnostics.Process.Start("example_qr_code.png");
        }

        void SaveQr()
        {


            string data = url;

            BarcodeWriter barcodeWriter = new BarcodeWriter();
            barcodeWriter.Format = BarcodeFormat.QR_CODE;
            barcodeWriter.Options = new ZXing.Common.EncodingOptions
            {
                Width = width,  // Genişlik
                Height = height, // Yükseklik
                Margin = margin    // Kenar boşluğu
            };

            barcodeWriter.Renderer = new ZXing.Rendering.BitmapRenderer { Foreground = front, Background = back };

            if (url != "")
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "PNG Files (*.png)|*.png|All files (*.*)|*.*";
                saveFileDialog.DefaultExt = "png";
                saveFileDialog.AddExtension = true;

                // Kullanıcıdan dosya adını al
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Bitmap qrCodeBitmap = barcodeWriter.Write(data);
                    qrCodeBitmap.Save(saveFileDialog.FileName);
                    System.Diagnostics.Process.Start(saveFileDialog.FileName);
                }
            }
        }

        private void qrPicture_Click(object sender, EventArgs e)
        {
            SaveQr();
        }

        private void txtWidth_TextChanged(object sender, EventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(txtWidth.Text))
            {
                width = Convert.ToInt32(txtWidth.Text);
                lblAlert.Visible = false;
                UpdateQr();
            }
            else 
            {
                width = 300;
                lblAlert.Visible = true;
            }

            if (checkBox1.Checked == true)
            {
                txtHeight.Text = txtWidth.Text;
            }
        }

        private void txtHeight_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtHeight.Text))
            {
                height = Convert.ToInt32(txtHeight.Text);
                lblAlert.Visible = false;
                UpdateQr();
            }
            else
            {
                height = 300;
                lblAlert.Visible = true;
            }
        }

        private void txtMargin_TextChanged(object sender, EventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(txtMargin.Text))
            {
                margin = Convert.ToInt32(txtMargin.Text);
                lblAlert.Visible = false;
                UpdateQr();
            }
            else
            {
                margin = 2;
                lblAlert.Visible = true;
            }
        }

        private void txtWidth_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void txtHeight_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);

        }

        private void txtMargin_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txtHeight.Enabled = false;
                txtHeight.Text = txtWidth.Text;
            }
            else
            {
                txtHeight.Enabled = true;
            }
        }


        private void label1_Click(object sender, EventArgs e) { }
        private void backPanel_Paint(object sender, PaintEventArgs e) { }
    }
}
